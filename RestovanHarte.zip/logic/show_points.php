<?php
$codes = $mysqli->query("SELECT code FROM codes WHERE facebook_id = '$user_id'");
$user_count = $codes->num_rows;
$points = $user_count *5;

echo "<br><h3>Beste " .  $user['name'] . " je hebt nu $user_count correcte code(s) op je account ingevoerd</h3>";
//echo "<h3>dus je hebt nu $points punten</h3>";

echo str_repeat('<img src="img/spaarpunt_hartje.png" height="100px">', $user_count);
?>