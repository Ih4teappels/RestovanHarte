<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resto van Harte BBQ</title>
    <script type="text/javascript" src="js/script.js"></script>
</head>