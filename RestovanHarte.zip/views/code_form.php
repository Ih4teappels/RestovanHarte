<form id="loginform" method="post" action="?page=check">
  code:<br>
    <input id="a" type="text" name="code1" maxlength="4" />-
    <input id="b" type="text" name="code2" maxlength="4" />-
    <input id="c" type="text" name="code3" maxlength="4" /><br>
        <input type="submit" value="checken">
</form>